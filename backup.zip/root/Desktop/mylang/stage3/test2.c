#include <stdio.h>

int main(int argc, char const *argv[])
{	
	int kar = 1==1?10:20;
	printf("val:%d",kar);
	return 0;
}