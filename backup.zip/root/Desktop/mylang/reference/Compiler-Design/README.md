# Compiler-Design

Implementation of Simple Integer Language Compiler. 

Description of Simple Integer Language: http://athena.nitc.ac.in/~kmurali/Compiler/sil.html

Description of Simple Integer Machine (target machine): http://athena.nitc.ac.in/~kmurali/Compiler/sim.html

More details can be found at http://silcnitc.github.io/ 
