yacc -y -d $1.y
lex $1.l
gcc -g y.tab.c lex.yy.c
